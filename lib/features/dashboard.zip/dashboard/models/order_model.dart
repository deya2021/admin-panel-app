import 'package:cloud_firestore/cloud_firestore.dart';

/// Order model for dashboard statistics
class OrderModel {
  final String id;
  final String userId;
  final double total;
  final String status;
  final DateTime createdAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.total,
    required this.status,
    required this.createdAt,
  });

  /// Create OrderModel from Firestore document
  factory OrderModel.fromMap(Map<String, dynamic> map, String id) {
    return OrderModel(
      id: id,
      userId: map['userId'] as String? ?? '',
      total: (map['total'] as num?)?.toDouble() ?? 0.0,
      status: map['status'] as String? ?? '',
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  /// Convert OrderModel to Map
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'total': total,
      'status': status,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}

