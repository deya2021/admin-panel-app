import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/error_view.dart';
import '../providers/dashboard_providers.dart';
import '../widgets/stat_card_widget.dart';
import '../models/order_model.dart';

/// Dashboard screen showing admin panel overview
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final statsAsync = ref.watch(dashboardStatsProvider);
    final ordersAsync = ref.watch(recentOrdersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'), // Dashboard
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'تحديث', // Refresh
            onPressed: () {
              ref.invalidate(dashboardStatsProvider);
              ref.invalidate(recentOrdersProvider);
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(dashboardStatsProvider);
          ref.invalidate(recentOrdersProvider);
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Stats Cards
              // Stats Cards
              statsAsync.when(
                data: (stats) => GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8, // ← تقليل من 12 إلى 8
                  crossAxisSpacing: 8, // ← تقليل من 12 إلى 8
                  childAspectRatio: 1.0, // ← تصغير من 1.2 إلى 1.0
                  padding: const EdgeInsets.all(4), // ← إضافة padding خارجي
                  children: [
                    StatCard(
                      title: 'إجمالي المستخدمين',
                      value: stats.totalUsers.toString(),
                      icon: Icons.people,
                      color: Colors.blue,
                    ),
                    StatCard(
                      title: 'إجمالي المنتجات',
                      value: stats.totalProducts.toString(),
                      icon: Icons.inventory_2,
                      color: Colors.green,
                    ),
                    StatCard(
                      title: 'منتجات قليلة المخزون',
                      value: stats.lowStockProducts.toString(),
                      icon: Icons.warning,
                      color: Colors.orange,
                    ),
                    StatCard(
                      title: 'طلبات استرداد معلقة',
                      value: stats.pendingRedemptions.toString(),
                      icon: Icons.pending_actions,
                      color: Colors.red,
                    ),
                  ],
                ),
                loading: () => const SizedBox(
                  height: 120, // ← تصغير من 150 إلى 120
                  child: Center(child: LoadingIndicator()),
                ),
                error: (error, stack) => ErrorView(
                  error: error.toString(),
                  onRetry: () => ref.invalidate(dashboardStatsProvider),
                ),
              ),

              const SizedBox(height: 24),

              // Orders Chart
              Text(
                'الطلبات خلال 7 أيام', // Orders in last 7 days
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              ordersAsync.when(
                data: (orders) => _buildOrdersChart(context, orders),
                loading: () => const SizedBox(
                  height: 300,
                  child: Center(child: LoadingIndicator()),
                ),
                error: (error, stack) => ErrorView(
                  error: error.toString(),
                  onRetry: () => ref.invalidate(recentOrdersProvider),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Build orders line chart
  /// Build orders line chart
  Widget _buildOrdersChart(BuildContext context, List<OrderModel> orders) {
    if (orders.isEmpty) {
      return const SizedBox(
        height: 300,
        child: Center(
          child:
              Text('لا توجد طلبات في آخر 7 أيام'), // No orders in last 7 days
        ),
      );
    }

    // Group orders by date with safe conversion
    final Map<DateTime, double> dailyTotals = {};
    for (var order in orders) {
      try {
        // معالجة آمنة للتاريخ
        DateTime orderDate;
        if (order.createdAt is Timestamp) {
          orderDate = (order.createdAt as Timestamp).toDate();
        } else if (order.createdAt is DateTime) {
          orderDate = order.createdAt;
        } else {
          // إذا كان نوع غير معروف، استخدم التاريخ الحالي
          orderDate = DateTime.now();
        }

        final date = DateTime(
          orderDate.year,
          orderDate.month,
          orderDate.day,
        );

        // معالجة آمنة للمبلغ
        double orderTotal;
        if (order.total is double) {
          orderTotal = order.total;
        } else if (order.total is int) {
          orderTotal = (order.total as int).toDouble();
        } else {
          orderTotal = 0.0;
        }

        dailyTotals[date] = (dailyTotals[date] ?? 0) + orderTotal;
      } catch (e) {
        print('⚠️ خطأ في معالجة طلب: $e');
        continue; // تخطي هذا الطلب والمتابعة للطلبات الأخرى
      }
    }

    // Create data points for last 7 days (always 7 points, zero if no data)
    final now = DateTime.now();
    final List<FlSpot> spots = [];

    for (int i = 6; i >= 0; i--) {
      final date =
          DateTime(now.year, now.month, now.day).subtract(Duration(days: i));
      final total = dailyTotals[date] ?? 0;
      spots.add(FlSpot(6 - i.toDouble(), total));
    }

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 300,
          child: LineChart(
            LineChartData(
              gridData: FlGridData(show: true),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 40,
                    getTitlesWidget: (value, meta) {
                      return Text(
                        value.toInt().toString(),
                        style: const TextStyle(fontSize: 10),
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 30,
                    getTitlesWidget: (value, meta) {
                      final date = DateTime.now().subtract(
                        Duration(days: 6 - value.toInt()),
                      );
                      return Text(
                        '${date.day}/${date.month}',
                        style: const TextStyle(fontSize: 10),
                      );
                    },
                  ),
                ),
                topTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                rightTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
              ),
              borderData: FlBorderData(show: true),
              lineBarsData: [
                LineChartBarData(
                  spots: spots,
                  isCurved: true,
                  color: Colors.blue,
                  barWidth: 3,
                  dotData: FlDotData(show: true),
                  belowBarData: BarAreaData(
                    show: true,
                    color: Colors.blue.withOpacity(0.2),
                  ),
                ),
              ],
              minY: 0,
            ),
          ),
        ),
      ),
    );
  }
}
