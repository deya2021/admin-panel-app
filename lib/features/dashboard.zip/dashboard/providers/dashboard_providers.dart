import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/dashboard_stats.dart';
import '../models/order_model.dart';

/// Provider for Firestore instance
final _firestoreProvider = Provider<FirebaseFirestore>((ref) {
  return FirebaseFirestore.instance;
});

/// Provider for dashboard stats from stats/main document
final dashboardStatsProvider = StreamProvider<DashboardStats>((ref) {
  final firestore = ref.watch(_firestoreProvider);

  return firestore.collection('stats').doc('main').snapshots().map((snapshot) {
    if (!snapshot.exists || snapshot.data() == null) {
      return DashboardStats.empty();
    }

    final data = snapshot.data()!;
    return DashboardStats(
      totalUsers: (data['totalUsers'] as num?)?.toInt() ?? 0,
      totalProducts: (data['totalProducts'] as num?)?.toInt() ?? 0,
      lowStockProducts: (data['lowStockProducts'] as num?)?.toInt() ?? 0,
      pendingRedemptions: (data['pendingRedemptions'] as num?)?.toInt() ?? 0,
    );
  });
});

/// Provider for recent orders (last 7 days)
/// Provider for recent orders (last 7 days)
final recentOrdersProvider = StreamProvider<List<OrderModel>>((ref) {
  final firestore = ref.watch(_firestoreProvider);
  final sevenDaysAgo = DateTime.now().subtract(const Duration(days: 7));

  return firestore
      .collection('orders')
      .where('createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(sevenDaysAgo))
      .orderBy('createdAt', descending: false)
      .snapshots()
      .map((snapshot) {
    return snapshot.docs.map((doc) {
      final data = doc.data();

      // معالجة آمنة للحقول مع مرونة
      final userId = data['userId'] as String? ?? data['uid'] as String? ?? '';

      // معالجة آمنة للمبلغ
      double total;
      if (data['total'] is double) {
        total = data['total'] as double;
      } else if (data['total'] is int) {
        total = (data['total'] as int).toDouble();
      } else if (data['total'] is num) {
        total = (data['total'] as num).toDouble();
      } else {
        total = 0.0;
      }

      // معالجة آمنة للحالة
      final status = data['status'] as String? ?? 'pending';

      // معالجة آمنة للتاريخ
      DateTime createdAt;
      if (data['createdAt'] is Timestamp) {
        createdAt = (data['createdAt'] as Timestamp).toDate();
      } else if (data['createdAt'] is DateTime) {
        createdAt = data['createdAt'] as DateTime;
      } else {
        createdAt = DateTime.now();
      }

      return OrderModel(
        id: doc.id,
        userId: userId,
        total: total,
        status: status,
        createdAt: createdAt,
      );
    }).toList();
  });
});
